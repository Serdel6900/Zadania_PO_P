package ZadaniaLaby4;

public class ZadaniaLab4 {
    protected  static void zad1(){}
    protected  static void zad2(){}
    protected  static void zad3(){}
    protected  static void zad4(){}
    protected  static void zad5(){}
    protected  static void zad6(){}
    protected  static void zad7(){}
}
